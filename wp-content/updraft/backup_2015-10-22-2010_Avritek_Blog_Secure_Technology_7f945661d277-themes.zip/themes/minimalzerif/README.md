# MinimalZerif

## Details:
 - **Theme name:** MinimalZerif
 - **Description:** Free WordPress Theme for WP.org.
 - **Author:** 9Pixels
 - **Author URI:** http://www.9pixels.co
 - **Template:** zerif-lite
 - **Version:** 1.0.2
 - **License:** GNU General Public License v2 or later
 - **License URI:** http://www.gnu.org/licenses/gpl-2.0.html
 - **Tags:** light, responsive-layout, one-column, custom-colors, custom-header, custom-menu, featured-images, sticky-post, translation-ready
 - **Text Domain:** minimalzerif

## License:

MinimalZerif WordPress Theme, Copyright (C) 2015 [9Pixels] (http://www.9pixels.co).

This theme, like WordPress, is licensed under the GPL. Use it to make something cool, have fun, and share what you've learned with others.